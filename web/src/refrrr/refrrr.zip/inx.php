<img src="images/sessin.png" /><br />
<span style="font-size:80%;color:#333;">Better web sessions</span><br />
Remember only one thing <span style="color:#ff7777;"><b>Drag links</b></span>
<br />
Enter a URL to visit with <i><b>sessin</b></i>
<form action="reader.php">
<input type="text" value="http://www." name="o"></input>
<button>Visit</button>
<br />
<span style="font-size:80%;"><i>This session will be stored on this browser.</i></span>
</form>
