<?php 

require_once 'collections/Session.php';
require_once 'collections/HNLinks.php';

Session::addLink();
?>
