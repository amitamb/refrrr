<?

require_once 'framework/basicFrameworkInclude.php';

define("ID", "_id");

$sessionId = requestParam(ID);

?>
<div>

<a href="share1.php" target="_blank">Share</a>

</div>
