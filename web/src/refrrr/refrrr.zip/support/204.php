<?php
//TODO: log whatever
header("HTTP/1.0 204 No Content");
?>