<?php 

require_once 'collections/Subscriber.php';
require_once 'framework/basicFrameworkInclude.php';

Subscriber::add();

redirectSuccess("index.php");

?>
