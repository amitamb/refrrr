<?php 

require_once 'collections/Session.php';

Session::removeLink();

?>
